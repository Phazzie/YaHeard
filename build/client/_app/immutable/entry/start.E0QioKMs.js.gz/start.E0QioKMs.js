import{a as t}from"../chunks/entry.CE65BH3d.js";export{t as start};

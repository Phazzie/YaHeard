import{a as t}from"../chunks/entry.Cyf-0x5I.js";export{t as start};
